package com.example.prueba;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class AhorrosFragment extends Fragment {

    private EditText editAhorroMensual;
    private EditText editMetaTotal;
    private Button btnCalcularTiempo;
    private TextView textResultado;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ahorros, container, false);

        // Initialize views
        editAhorroMensual = view.findViewById(R.id.edit_ahorro_mensual);
        editMetaTotal = view.findViewById(R.id.edit_meta_total);
        btnCalcularTiempo = view.findViewById(R.id.btn_calcular_tiempo);
        textResultado = view.findViewById(R.id.text_resultado);

        // Set click listener
        btnCalcularTiempo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularTiempo();
            }
        });

        return view;
    }

    private void calcularTiempo() {
        String ahorroMensualStr = editAhorroMensual.getText().toString().trim();
        String metaTotalStr = editMetaTotal.getText().toString().trim();

        if (ahorroMensualStr.isEmpty() || metaTotalStr.isEmpty()) {
            Toast.makeText(getContext(), "Ingrese valores válidos", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double ahorroMensual = Double.parseDouble(ahorroMensualStr);
            double metaTotal = Double.parseDouble(metaTotalStr);

            if (ahorroMensual <= 0 || metaTotal <= 0) {
                Toast.makeText(getContext(), "Ingrese valores válidos", Toast.LENGTH_SHORT).show();
                return;
            }

            double tiempoEstimado = metaTotal / ahorroMensual;
            textResultado.setText(String.format("Tiempo estimado: %.1f meses", tiempoEstimado));

        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Ingrese valores válidos", Toast.LENGTH_SHORT).show();
        }
    }
}
