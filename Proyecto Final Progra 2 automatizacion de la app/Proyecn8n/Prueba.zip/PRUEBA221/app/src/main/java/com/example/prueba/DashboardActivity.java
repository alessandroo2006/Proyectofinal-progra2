package com.example.prueba;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DashboardActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigation;
    private TextView textUsuario;
    private TextView textSaldo;
    private TextView textIngresos;
    private TextView textGastos;
    private TextView textAhorro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize views
        bottomNavigation = findViewById(R.id.bottom_navigation);
        textUsuario = findViewById(R.id.text_usuario);
        textSaldo = findViewById(R.id.text_saldo);
        textIngresos = findViewById(R.id.text_ingresos);
        textGastos = findViewById(R.id.text_gastos);
        textAhorro = findViewById(R.id.text_ahorro);

        // Set up bottom navigation
        bottomNavigation.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            
            if (item.getItemId() == R.id.nav_inicio) {
                selectedFragment = new InicioFragment();
            } else if (item.getItemId() == R.id.nav_gastos) {
                selectedFragment = new GastosFragment();
            } else if (item.getItemId() == R.id.nav_ahorros) {
                selectedFragment = new AhorrosFragment();
            } else if (item.getItemId() == R.id.nav_suenos) {
                selectedFragment = new SuenosFragment();
            } else if (item.getItemId() == R.id.nav_perfil) {
                selectedFragment = new PerfilFragment();
            }

            if (selectedFragment != null) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.contenedor_fragment, selectedFragment);
                transaction.commit();
                return true;
            }
            
            return false;
        });

        // Set default fragment
        if (savedInstanceState == null) {
            bottomNavigation.setSelectedItemId(R.id.nav_inicio);
        }
    }
}
