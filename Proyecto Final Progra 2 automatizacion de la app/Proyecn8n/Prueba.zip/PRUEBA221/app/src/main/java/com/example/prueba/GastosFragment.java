package com.example.prueba;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class GastosFragment extends Fragment {

    private Spinner spinnerFiltro;
    private RecyclerView recyclerTransacciones;
    private TransaccionAdapter adapter;
    private List<Transaccion> transacciones;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_gastos, container, false);

        // Initialize views
        spinnerFiltro = view.findViewById(R.id.spinner_filtro);
        recyclerTransacciones = view.findViewById(R.id.recycler_transacciones);

        // Setup spinner
        String[] filtros = {"Este mes", "Último mes", "Este año"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, filtros);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFiltro.setAdapter(spinnerAdapter);

        // Setup spinner listener
        spinnerFiltro.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedFilter = filtros[position];
                Toast.makeText(getContext(), "Filtro seleccionado: " + selectedFilter, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // Setup RecyclerView
        recyclerTransacciones.setLayoutManager(new LinearLayoutManager(getContext()));

        // Create sample data
        transacciones = new ArrayList<>();
        transacciones.add(new Transaccion("Compra supermercado", 150.50, "gasto", "2024-01-15"));
        transacciones.add(new Transaccion("Salario", 2500.00, "ingreso", "2024-01-01"));
        transacciones.add(new Transaccion("Gasolina", 80.00, "gasto", "2024-01-10"));
        transacciones.add(new Transaccion("Freelance", 500.00, "ingreso", "2024-01-20"));
        transacciones.add(new Transaccion("Restaurante", 45.75, "gasto", "2024-01-18"));

        adapter = new TransaccionAdapter(transacciones);
        recyclerTransacciones.setAdapter(adapter);

        return view;
    }
}
