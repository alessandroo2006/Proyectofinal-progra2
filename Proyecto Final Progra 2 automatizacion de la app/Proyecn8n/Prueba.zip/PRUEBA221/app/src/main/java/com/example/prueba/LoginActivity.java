package com.example.prueba;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editUsuario;
    private EditText editContrasena;
    private Button btnIniciarSesion;
    private Button btnRegistrarse;
    private Button btnBiometrico;
    private Button btnPasskey;
    private UserRepository userRepository;
    private SessionManager sessionManager;
    private BiometricHelper biometricHelper;
    private PasskeyManager passkeyManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize views
        editUsuario = findViewById(R.id.edit_usuario);
        editContrasena = findViewById(R.id.edit_contrasena);
        btnIniciarSesion = findViewById(R.id.btn_iniciar_sesion);
        btnRegistrarse = findViewById(R.id.btn_registrarse);
        btnBiometrico = findViewById(R.id.btn_biometrico);
        btnPasskey = findViewById(R.id.btn_passkey);

        // Initialize repository and managers
        userRepository = new UserRepository(this);
        sessionManager = new SessionManager(this);
        biometricHelper = new BiometricHelper();
        passkeyManager = new PasskeyManager(this);

        // Setup autofill
        AutofillHelper.setupAutofillForLogin(editUsuario, editContrasena);

        // Validate app integrity
        if (!SecurityHelper.validateAppIntegrity(this)) {
            Toast.makeText(this, "Advertencia: Integridad de la aplicación comprometida", Toast.LENGTH_LONG).show();
        }

        // Check if user is already logged in
        if (sessionManager.isLoggedIn()) {
            Intent intent = new Intent(this, DashboardActivity.class);
            intent.putExtra("user_id", sessionManager.getUserId());
            intent.putExtra("username", sessionManager.getUsername());
            startActivity(intent);
            finish();
            return;
        }

        // Set click listeners
        btnIniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin();
            }
        });

        btnRegistrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        // Setup biometric authentication
        if (BiometricHelper.isBiometricAvailable(this)) {
            btnBiometrico.setVisibility(View.VISIBLE);
            btnBiometrico.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    authenticateWithBiometric();
                }
            });
        } else {
            btnBiometrico.setVisibility(View.GONE);
        }

        // Setup passkey authentication
        btnPasskey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                authenticateWithPasskey();
            }
        });

        // Setup session timeout callback
        sessionManager.setSessionTimeoutCallback(new SessionManager.SessionTimeoutCallback() {
            @Override
            public void onSessionTimeout() {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, "Sesión expirada. Por favor, inicie sesión nuevamente.", Toast.LENGTH_LONG).show();
                    sessionManager.logoutUser();
                });
            }
        });
    }

    private void handleLogin() {
        // Get text from both fields
        String usuario = editUsuario.getText().toString().trim();
        String contrasena = editContrasena.getText().toString().trim();

        // Validate that fields are not empty
        if (usuario.isEmpty() || contrasena.isEmpty()) {
            Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show loading state
        btnIniciarSesion.setEnabled(false);
        btnIniciarSesion.setText("Iniciando sesión...");

        // Authenticate user
        userRepository.loginUser(usuario, contrasena, new UserRepository.LoginCallback() {
            @Override
            public void onLoginSuccess(User user) {
                runOnUiThread(() -> {
                    // Save user session with timeout
                    sessionManager.createLoginSession(user.getId(), user.getUsername(), user.getEmail());
                    
                    // Navigate to Dashboard
                    Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                    intent.putExtra("user_id", user.getId());
                    intent.putExtra("username", user.getUsername());
                    startActivity(intent);
                    finish();
                });
            }

            @Override
            public void onLoginFailure(String message) {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                    btnIniciarSesion.setEnabled(true);
                    btnIniciarSesion.setText("Iniciar Sesión");
                });
            }
        });
    }

    private void authenticateWithBiometric() {
        BiometricHelper.authenticateWithBiometric(this, new BiometricHelper.BiometricCallback() {
            @Override
            public void onAuthenticationSucceeded() {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, "Autenticación biométrica exitosa", Toast.LENGTH_SHORT).show();
                    // Aquí podrías implementar lógica para obtener credenciales almacenadas
                    // o usar un usuario previamente autenticado
                });
            }

            @Override
            public void onAuthenticationFailed() {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, "Autenticación biométrica fallida", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onAuthenticationError(int errorCode, String errorMessage) {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, "Error biométrico: " + errorMessage, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void authenticateWithPasskey() {
        String username = editUsuario.getText().toString().trim();
        if (username.isEmpty()) {
            Toast.makeText(this, "Ingrese su nombre de usuario para usar passkey", Toast.LENGTH_SHORT).show();
            return;
        }

        passkeyManager.signInWithPasskey(new PasskeyManager.PasskeyCallback() {
            @Override
            public void onPasskeySuccess(String credential) {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, "Autenticación con passkey exitosa", Toast.LENGTH_SHORT).show();
                    // Procesar credenciales y continuar con el login
                    handlePasskeyLogin(credential);
                });
            }

            @Override
            public void onPasskeyError(String error) {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, "Error con passkey: " + error, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void handlePasskeyLogin(String credential) {
        // Implementar lógica para procesar las credenciales de passkey
        // y realizar el login correspondiente
        Toast.makeText(this, "Login con passkey implementado", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sessionManager != null) {
            sessionManager.onDestroy();
        }
    }
}
