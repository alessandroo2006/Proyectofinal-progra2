package com.example.prueba;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NuevoSuenoActivity extends AppCompatActivity {

    private EditText editNombreSueno;
    private EditText editMontoObjetivo;
    private EditText editFechaLimite;
    private Spinner spinnerPrioridad;
    private Button btnGuardar;
    private String prioridadSeleccionada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_sueno);

        // Initialize views
        editNombreSueno = findViewById(R.id.edit_nombre_sueno);
        editMontoObjetivo = findViewById(R.id.edit_monto_objetivo);
        editFechaLimite = findViewById(R.id.edit_fecha_limite);
        spinnerPrioridad = findViewById(R.id.spinner_prioridad);
        btnGuardar = findViewById(R.id.btn_guardar);

        // Setup spinner
        String[] prioridades = {"Alta", "Media", "Baja"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, prioridades);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPrioridad.setAdapter(spinnerAdapter);

        // Set default selection
        prioridadSeleccionada = prioridades[0];

        // Setup spinner listener
        spinnerPrioridad.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                prioridadSeleccionada = prioridades[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // Set click listener
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarSueno();
            }
        });
    }

    private void guardarSueno() {
        String nombre = editNombreSueno.getText().toString().trim();
        String montoStr = editMontoObjetivo.getText().toString().trim();
        String fechaLimite = editFechaLimite.getText().toString().trim();

        if (nombre.isEmpty() || montoStr.isEmpty() || fechaLimite.isEmpty()) {
            Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double monto = Double.parseDouble(montoStr);
            if (monto <= 0) {
                Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Sueño guardado", Toast.LENGTH_SHORT).show();
        finish();
    }
}
