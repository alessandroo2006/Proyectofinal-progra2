package com.example.prueba;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class PerfilFragment extends Fragment {

    private RecyclerView recyclerMensajes;
    private EditText editPregunta;
    private Button btnEnviar;
    private MensajeAdapter adapter;
    private List<Mensaje> mensajes;
    private ChatRepository chatRepository;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_perfil, container, false);

        // Initialize views
        recyclerMensajes = view.findViewById(R.id.recycler_mensajes);
        editPregunta = view.findViewById(R.id.edit_pregunta);
        btnEnviar = view.findViewById(R.id.btn_enviar);
        
        // Initialize chat repository
        chatRepository = new ChatRepository();

        // Setup RecyclerView
        recyclerMensajes.setLayoutManager(new LinearLayoutManager(getContext()));

        // Create sample data
        mensajes = new ArrayList<>();
        mensajes.add(new Mensaje("¡Hola! Soy tu coach financiero. ¿En qué puedo ayudarte?", false));
        mensajes.add(new Mensaje("Recuerda revisar tus gastos regularmente", false));
        mensajes.add(new Mensaje("Te recomiendo ahorrar al menos el 20% de tus ingresos", false));

        adapter = new MensajeAdapter(mensajes);
        recyclerMensajes.setAdapter(adapter);

        // Set click listener
        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarMensaje();
            }
        });

        return view;
    }

    private void enviarMensaje() {
        String pregunta = editPregunta.getText().toString().trim();

        if (pregunta.isEmpty()) {
            Toast.makeText(getContext(), "Escribe un mensaje", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add user message
        mensajes.add(new Mensaje(pregunta, true));
        adapter.notifyItemInserted(mensajes.size() - 1);
        
        // Clear field
        editPregunta.setText("");
        
        // Show loading message
        mensajes.add(new Mensaje("Escribiendo...", false));
        adapter.notifyItemInserted(mensajes.size() - 1);
        
        // Scroll to bottom
        recyclerMensajes.scrollToPosition(mensajes.size() - 1);
        
        // Send to API
        chatRepository.sendMessage(pregunta, new ChatRepository.ChatCallback() {
            @Override
            public void onSuccess(String response) {
                // Remove loading message
                mensajes.remove(mensajes.size() - 1);
                adapter.notifyItemRemoved(mensajes.size());
                
                // Add AI response
                mensajes.add(new Mensaje(response, false));
                adapter.notifyItemInserted(mensajes.size() - 1);
                
                // Scroll to bottom
                recyclerMensajes.scrollToPosition(mensajes.size() - 1);
            }
            
            @Override
            public void onError(String error) {
                // Remove loading message
                mensajes.remove(mensajes.size() - 1);
                adapter.notifyItemRemoved(mensajes.size());
                
                // Add error message
                mensajes.add(new Mensaje("Error: " + error, false));
                adapter.notifyItemInserted(mensajes.size() - 1);
                
                // Scroll to bottom
                recyclerMensajes.scrollToPosition(mensajes.size() - 1);
                
                Toast.makeText(getContext(), "Error al enviar mensaje", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
