package com.example.prueba;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Log;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;
import java.io.ByteArrayInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

public class SecurityHelper {
    
    private static final String TAG = "SecurityHelper";
    
    public static boolean validateAppIntegrity(Context context) {
        try {
            // Obtener la firma de la aplicación
            Signature[] signatures = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES)
                    .signatures;
            
            if (signatures.length == 0) {
                Log.w(TAG, "No se encontraron firmas de la aplicación");
                return false;
            }
            
            // Verificar la primera firma
            Signature signature = signatures[0];
            byte[] cert = signature.toByteArray();
            
            // Crear certificado X.509
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            X509Certificate x509Cert = (X509Certificate) certFactory.generateCertificate(
                    new ByteArrayInputStream(cert));
            
            // Verificar que el certificado no haya expirado
            x509Cert.checkValidity();
            
            // Calcular hash SHA-256 del certificado
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] certHash = md.digest(cert);
            
            Log.d(TAG, "Integridad de la aplicación validada correctamente");
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "Error validando integridad de la aplicación", e);
            return false;
        }
    }
    
    public static MasterKey createMasterKey(Context context) {
        try {
            return new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
        } catch (Exception e) {
            Log.e(TAG, "Error creando MasterKey", e);
            return null;
        }
    }
    
    public static EncryptedSharedPreferences createEncryptedPreferences(Context context, String fileName) {
        try {
            MasterKey masterKey = createMasterKey(context);
            if (masterKey == null) {
                return null;
            }
            
            // API correcta: EncryptedSharedPreferences.create(Context, String, MasterKey, PrefKeyEncryptionScheme, PrefValueEncryptionScheme)
            return (EncryptedSharedPreferences) EncryptedSharedPreferences.create(
                    context,                    // Context como primer parámetro
                    fileName,                   // String como segundo parámetro
                    masterKey,                  // MasterKey como tercer parámetro
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception e) {
            Log.e(TAG, "Error creando EncryptedSharedPreferences", e);
            return null;
        }
    }
    
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Error hasheando contraseña", e);
            return password; // Fallback a contraseña sin hash
        }
    }
}
