package com.example.prueba;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class SuenosFragment extends Fragment {

    private RecyclerView recyclerSuenos;
    private Button btnAgregarSueno;
    private SuenoAdapter adapter;
    private List<Sueno> suenos;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_suenos, container, false);

        // Initialize views
        recyclerSuenos = view.findViewById(R.id.recycler_suenos);
        btnAgregarSueno = view.findViewById(R.id.btn_agregar_sueno);

        // Setup RecyclerView
        recyclerSuenos.setLayoutManager(new LinearLayoutManager(getContext()));

        // Create sample data
        suenos = new ArrayList<>();
        suenos.add(new Sueno("Viaje a Europa", 5000.00, 1200.00, "2024-12-31", "Alta"));
        suenos.add(new Sueno("Casa nueva", 50000.00, 5000.00, "2025-06-30", "Media"));

        adapter = new SuenoAdapter(suenos);
        recyclerSuenos.setAdapter(adapter);

        // Set click listener
        btnAgregarSueno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), NuevoSuenoActivity.class);
                startActivity(intent);
            }
        });

        return view;
    }
}
